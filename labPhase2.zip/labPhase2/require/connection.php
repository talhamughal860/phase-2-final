<?php
$hostname = "localhost";
$username= "root";
$pwd= "";
$db = "StudentData";
$conn = mysqli_connect($hostname,$username,$pwd,$db);
if (!$conn){
    echo mysqli_connect_error();
}else{
    echo "Data-Base connect successfully";
}
?>