<?php
    @require('require/Connection.php');
    
    $Fname = $_POST['Fname'];
    $Sname = $_POST['Sname'];
    $FAname = $_POST['FAname'];
    $RollNo = $_POST['RollNo'];
    $Age = $_POST['Age'];
    $Pno = $_POST['Pno'];
    $Class = $_POST['Class'];
    $Addresss = $_POST['Addresss'];
    $ADate = $_POST['ADate'];
    $DOB = $_POST['DOB'];
    
    $query = "INSERT INTO StudentData (Fname,Sname,FAname,RollNo,Age,Pno,Class,Addresss,ADate,DOB)
    VALUES ('$Fname','$Sname','$FAname','$RollNo','$Age','$Pno','$Class','$Addresss','$ADate','$DOB')";

    $run = mysqli_query($conn,$query);
    if (!$run){
        
  die('Could not enter data: ' . mysqli_error($conn));
    }
        header('location:index.php?status=yes');
        

mysqli_close($conn);    
   
?>