<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Phase II</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
</head>
<body>
        <div class="overlay"></div>
        <video poster="img/bg (2).jpg" playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop" id="video-bg">
          <source src="img/bg-video.mp4" type="video/mp4">
        </video>
     
        <center>
        <div class="container">
        <h1>Enter the Data Of the Student</h1>
        <form action="add-process.php" method="post" >
            <input type="text" name="Fname" id="" placeholder="First Name..."><br>
            <input type="text" name="Sname" id="" placeholder="Second Name..."><br>
            <input type="text" name="FAname" id="" placeholder="Father's Name..."><br>
            <input type="number" name="RollNo" id="" placeholder="Roll no.."><br>
            <input type="number" name="Age" id="" placeholder="Student's Age"><br>
            <input type="number" name="Pno" id="" placeholder="Parent's phone number"><br>
            <input type="number" name="Class" id="" placeholder="Enter Class"><br>
            <input type="text" name="Addresss" id="address" placeholder="Student's Address"><br>

            <label for="">Admission Date:&nbsp</label><br>
            <input type="date" name="ADate" id="date"><br>
            
            <label for="">Date Of Birth:&nbsp</label><br>
            <input type="date" name="DOB" id="date"><br>
            <button>Add Record</button>
            <a id="viewNav" href="viewPage.php">View Records</a>
        </form>
    </div>
</center>
</body>
</html>