<?php
@require("require/connection.php"); 

$RollNo		= $_POST['RollNo'];  

$Fname = $_POST['Fname'];
$Sname = $_POST['Sname'];
$FAname = $_POST['FAname'];
$Age = $_POST['Age'];
$Pno = $_POST['Pno'];
$Class = $_POST['Class'];
$Addresss = $_POST['Addresss'];
$ADate = $_POST['ADate'];
$DOB = $_POST['DOB'];

	$sql = "UPDATE StudentData
	SET Fname= '$Fname', Sname='$Sname',FAname='$FAname',
	 Age='$Age',Pno='$Pno',
	Class='$Class',Addresss='$Addresss',ADate='$ADate',DOB='$DOB'
	WHERE RollNo=$RollNo ";

$result = mysqli_query($conn, $sql);
 
if(!$result)
{
  die('Could not enter data: ' . mysql_error());
}
 
	header("Location: viewPage.php?status=updated");
 

mysql_close($connection);
?>