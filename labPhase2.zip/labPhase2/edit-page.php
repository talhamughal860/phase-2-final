
<?php require("require/connection.php"); ?>

  <?php	
		$RollNo = $_GET['RollNo'];
		$sql="SELECT * FROM StudentData where RollNo='$RollNo'";
		$result=mysqli_query($conn,$sql);
		
		$count=mysqli_num_rows($result);
			
		if ($count > 0) 
		{
			$row = mysqli_fetch_array($result);
		} 
	
  ?>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit</title>
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
  <div class="overlay"></div>
        <video poster="img/bg (2).jpg" playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop" id="video-bg">
          <source src="img/bg-video.mp4" type="video/mp4">
        </video>
        <center>
        <h1 id="viewRecords">View Records</h1>
        <div class="container">

 	<form id="editPage" name="myform" action="edit-process.php" method="post"  enctype="multipart/form-data">
	<input type="hidden" name="RollNo" value="<?=$row["RollNo"]?>" >
            <input type="text" name="Fname" id="" placeholder="First Name..." value="<?=$row["Fname"]?>"><br>
            <input type="text" name="Sname" id="" placeholder="Second Name..." value="<?=$row["Sname"]?>"><br>
            <input type="text" name="FAname" id="" placeholder="Father's Name..." value="<?=$row["FAname"]?>"><br>
            <input type="number" name="RollNo" id="" placeholder="Roll no.." value="<?=$row["RollNo"]?>"><br>
            <input type="number" name="Age" id="" placeholder="Student's Age" value="<?=$row["Age"]?>"><br>
            <input type="number" name="Pno" id="" placeholder="Parent's phone number" value="<?=$row["Pno"]?>"><br>
            <input type="number" name="Class" id="" placeholder="Enter Class" value="<?=$row["Class"]?>"><br>
            <input type="text" name="Addresss" id="address" placeholder="Student's Address" value="<?=$row["Addresss"]?>"><br>

            <label for="">Admission Date:&nbsp</label><br>
            <input type="date" name="ADate" id="date" value="<?=$row["ADate"]?>"><br>
            
            <label for="">Date Of Birth:&nbsp</label><br>
            <input type="date" name="DOB" id="date" value="<?=$row["DOB"]?>"><br>
            <button>Add Record</button>
            <a id="viewNav" href="viewPage.php">View Records</a>
  </form>  
  </div>
  </center>  
  </body>
  </html>
