<?php
require('require/Connection.php');?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View-Page</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="overlay"></div>
        <video poster="img/bg (2).jpg" playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop" id="video-bg">
          <source src="img/bg-video.mp4" type="video/mp4">
        </video>
        <h1 id="viewRecords">View Records</h1>

<?php
$query = "SELECT * FROM StudentData";
$run = mysqli_query($conn,$query);

        while ($row = mysqli_fetch_array($run)) 
        {
            
        ?>
        
          <div class="datafile">
              
        <span>Roll No: </span><?=$row["RollNo"]?><br>
        <span>First Name:  &nbsp&nbsp&nbsp&nbsp </span><?=$row["Fname"]?><br>
        <span>Second Name:&nbsp&nbsp  </span><?=$row["Sname"]?><br>
        <span>Father's Name:&nbsp&nbsp</span><?=$row["FAname"]?><br>
        <span>Age:     &nbsp&nbsp     </span><?=$row["Age"]?><br>
        <span>Phone No: &nbsp&nbsp    </span><?=$row["Pno"]?><br>
        <span>Class:  &nbsp&nbsp      </span><?=$row["Class"]?><br>
        <span>Address: &nbsp&nbsp     </span><?=$row["Addresss"]?><br>
        <span>Date: &nbsp&nbsp        </span><?=$row["ADate"]?><br>
        <span>DOB:  &nbsp&nbsp        </span><?=$row["DOB"]?><br>
        <br>

        <a id="edit" href="edit-page.php?RollNo=<?=$row["RollNo"]?>">Edit</a> | 
		<a id="edit" href="DeleteRecord.php?RollNo=<?=$row["RollNo"]?>">Delete</a>
    </div>
<?php
        }
?>
            <a id="viewNav" href="index.php">Add Records</a>
</body>
</html>
       