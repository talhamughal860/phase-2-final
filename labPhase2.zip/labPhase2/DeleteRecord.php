<?php
require('require/Connection.php');
$RollNo = $_GET['RollNo'];

$query = "DELETE FROM StudentData WHERE RollNo=$RollNo";

$run = mysqli_query($conn,$query);
if (!$run){
    echo "Oops !! ERROR";
}else{
    header('location:viewPage.php?status=deleted');
}
?>